"""
Train NBA Finals prediction models using historical Finals teams.

The model never uses `champion` as an input feature. Champion is only the label.
Each Finals year is converted into one matchup row:
    Team A features - Team B features
label:
    1 if Team A won, 0 if Team B won
"""

from pathlib import Path
import argparse
import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, log_loss
from sklearn.inspection import permutation_importance

FEATURES = [
    "ortg", "drtg", "seed", "wins", "mvp5", "dpoy5", "allstars",
    "finals5", "titles5", "threept_pct", "twopt_pct", "ft_pct",
]


def load_team_data(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path, skip_blank_lines=True)
    required = ["year", "team", "champion"] + FEATURES
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    df["year"] = df["year"].astype(int)
    df["champion"] = pd.to_numeric(df["champion"], errors="coerce")
    for col in FEATURES:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def make_matchup_data(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for year, group in df.groupby("year", sort=True):
        group = group.reset_index(drop=True)
        if len(group) != 2:
            raise ValueError(f"Expected 2 teams for {year}, found {len(group)}")
        a = group.iloc[0]
        b = group.iloc[1]
        row = {"year": int(year), "team_a": a["team"], "team_b": b["team"]}
        for f in FEATURES:
            row[f"{f}_diff"] = float(a[f] - b[f])
        if pd.isna(a["champion"]) or pd.isna(b["champion"]):
            row["team_a_won"] = np.nan
            row["winner"] = ""
        else:
            row["team_a_won"] = int(a["champion"] == 1)
            row["winner"] = a["team"] if row["team_a_won"] == 1 else b["team"]
        rows.append(row)
    return pd.DataFrame(rows)


def train_and_evaluate(matchups: pd.DataFrame, output_dir: str | Path) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    feature_cols = [f"{f}_diff" for f in FEATURES]

    train = matchups[(matchups["year"] >= 1980) & (matchups["year"] <= 2015)].copy()
    test = matchups[(matchups["year"] >= 2016) & (matchups["year"] <= 2025)].copy()
    predict = matchups[matchups["year"] == 2026].copy()

    X_train = train[feature_cols]
    y_train = train["team_a_won"].astype(int)
    X_test = test[feature_cols]
    y_test = test["team_a_won"].astype(int)

    models = {
        "logistic_regression": Pipeline([
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(max_iter=5000, random_state=42)),
        ]),
        "random_forest": RandomForestClassifier(
            n_estimators=500, max_depth=3, min_samples_leaf=2, random_state=42
        ),
        "linear_svm": Pipeline([
            ("scaler", StandardScaler()),
            ("model", SVC(kernel="linear", probability=True, random_state=42)),
        ]),
        "rbf_svm": Pipeline([
            ("scaler", StandardScaler()),
            ("model", SVC(kernel="rbf", probability=True, random_state=42)),
        ]),
    }

    summary_rows = []
    prediction_rows = []

    for name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        prob = model.predict_proba(X_test)[:, 1]

        summary_rows.append({
            "model": name,
            "train_matchups": len(train),
            "test_matchups": len(test),
            "test_accuracy": round(accuracy_score(y_test, pred), 3),
            "test_log_loss": round(log_loss(y_test, prob), 3),
        })

        test_predictions = test[["year", "team_a", "team_b", "winner"]].copy()
        test_predictions["model"] = name
        test_predictions["actual_team_a_won"] = y_test.values
        test_predictions["predicted_team_a_won"] = pred
        test_predictions["prob_team_a_wins"] = prob
        test_predictions["predicted_winner"] = np.where(pred == 1, test_predictions["team_a"], test_predictions["team_b"])
        test_predictions.to_csv(output_dir / f"{name}_test_predictions.csv", index=False)

        if not predict.empty:
            X_predict = predict[feature_cols]
            pred_2026 = model.predict(X_predict)
            prob_2026 = model.predict_proba(X_predict)[:, 1]
            for i, (_, row) in enumerate(predict.iterrows()):
                prediction_rows.append({
                    "model": name,
                    "year": int(row["year"]),
                    "team_a": row["team_a"],
                    "team_b": row["team_b"],
                    "prob_team_a_wins": round(float(prob_2026[i]), 4),
                    "prob_team_b_wins": round(float(1 - prob_2026[i]), 4),
                    "predicted_winner": row["team_a"] if pred_2026[i] == 1 else row["team_b"],
                })

        if name == "logistic_regression":
            coef = model.named_steps["model"].coef_[0]
            pd.DataFrame({
                "feature": feature_cols,
                "coefficient": coef,
                "abs_coefficient": np.abs(coef),
            }).sort_values("abs_coefficient", ascending=False).to_csv(
                output_dir / "logistic_regression_coefficients.csv", index=False
            )
        elif name == "linear_svm":
            coef = model.named_steps["model"].coef_[0]
            pd.DataFrame({
                "feature": feature_cols,
                "coefficient": coef,
                "abs_coefficient": np.abs(coef),
            }).sort_values("abs_coefficient", ascending=False).to_csv(
                output_dir / "linear_svm_coefficients.csv", index=False
            )
        elif name == "random_forest":
            pd.DataFrame({
                "feature": feature_cols,
                "importance": model.feature_importances_,
            }).sort_values("importance", ascending=False).to_csv(
                output_dir / "random_forest_feature_importance.csv", index=False
            )

        perm = permutation_importance(
            model, X_test, y_test, n_repeats=100, random_state=42, scoring="accuracy"
        )
        pd.DataFrame({
            "feature": feature_cols,
            "permutation_importance_mean": perm.importances_mean,
            "permutation_importance_std": perm.importances_std,
        }).sort_values("permutation_importance_mean", ascending=False).to_csv(
            output_dir / f"{name}_permutation_importance.csv", index=False
        )

    pd.DataFrame(summary_rows).to_csv(output_dir / "model_summary.csv", index=False)
    pd.DataFrame(prediction_rows).to_csv(output_dir / "prediction_2026.csv", index=False)

    print("\nModel summary:")
    print(pd.DataFrame(summary_rows).to_string(index=False))
    if prediction_rows:
        print("\n2026 predictions:")
        print(pd.DataFrame(prediction_rows).to_string(index=False))
    print(f"\nSaved outputs to: {output_dir}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/nba_finals_1980_2026.csv")
    parser.add_argument("--out", default="outputs")
    args = parser.parse_args()
    df = load_team_data(args.data)
    matchups = make_matchup_data(df)
    Path(args.out).mkdir(parents=True, exist_ok=True)
    matchups.to_csv(Path(args.out) / "matchup_dataset.csv", index=False)
    train_and_evaluate(matchups, args.out)


if __name__ == "__main__":
    main()
