# NBA Finals Prediction Project

This project predicts the winner of an NBA Finals matchup using regular-season team data only.

## Dataset

Input file:

```text
data/nba_finals_1980_2026.csv
```

Columns:

```text
year, team, champion, ortg, drtg, seed, wins, mvp5, dpoy5, allstars, finals5, titles5, threept_pct, twopt_pct, ft_pct
```

Splits:

```text
1980-2015 = train
2016-2025 = test
2026 = predict
```

2026 champion should stay blank.

## Key modeling choice

The model does not train on standalone team rows. Each Finals becomes one matchup row:

```text
Team A features - Team B features
```

The label is:

```text
1 if Team A won
0 if Team B won
```

This avoids letting the model use champion information as an input.

## Models

- Logistic Regression
- Random Forest
- Linear SVM
- RBF SVM

## Run

```bash
pip install -r requirements.txt
python src/audit_data.py
python src/train_models.py
```

Outputs are saved in `outputs/`.

Important files:

- `model_summary.csv`
- `prediction_2026.csv`
- `matchup_dataset.csv`
- `logistic_regression_coefficients.csv`
- `random_forest_feature_importance.csv`
- `linear_svm_coefficients.csv`
- permutation importance files

## Warning

The training set has only 36 Finals matchups, so results should be interpreted carefully. This is a good exploratory model, not a guaranteed prediction engine.
